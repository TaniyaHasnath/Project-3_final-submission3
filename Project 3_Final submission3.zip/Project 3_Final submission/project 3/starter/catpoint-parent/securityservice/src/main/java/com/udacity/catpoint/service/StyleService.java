package com.udacity.catpoint.service;

import java.awt.Font;

public final class StyleService {

    /** Heading font used by the GUI. */
    public static final Font HEADING_FONT = new Font("SansSerif", Font.BOLD, 18);

    private StyleService() { /* utility class */ }

    /** Optional: use this if you prefer not to expose the static directly. */
    public static Font headingFont() {
        // Fonts are immutable, but returning the constant keeps callers from reassigning it.
        return HEADING_FONT;
    }
}
