package com.udacity.catpoint.application;

import com.udacity.catpoint.data.AlarmStatus;
import com.udacity.catpoint.service.SecurityService;
import com.udacity.catpoint.service.StyleService;
import net.miginfocom.swing.MigLayout;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * Panel containing the camera output. Users can load a default image,
 * open an image from disk, and scan it via SecurityService.
 */
public class ImagePanel extends JPanel implements StatusListener {
    private final SecurityService securityService;

    private final JLabel cameraHeader;
    private final JLabel cameraLabel;
    private BufferedImage currentCameraImage;

    private static final int IMAGE_WIDTH  = 300;
    private static final int IMAGE_HEIGHT = 225;

    /** Default image bundled under src/main/resources */
    private static final String DEFAULT_SAMPLE_PATH = "/sample-cat.jpg";

    public ImagePanel(SecurityService securityService) {
        super(new MigLayout());
        this.securityService = securityService;
        securityService.addStatusListener(this);

        cameraHeader = new JLabel("Camera Feed");
        cameraHeader.setFont(StyleService.HEADING_FONT);

        cameraLabel = new JLabel();
        cameraLabel.setBackground(Color.WHITE);
        cameraLabel.setPreferredSize(new Dimension(IMAGE_WIDTH, IMAGE_HEIGHT));
        cameraLabel.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));

        // Load default image from resources
        JButton refreshButton = new JButton("Refresh Camera");
        refreshButton.addActionListener(e -> loadDefaultImage());

        // Open image from disk
        JButton openButton = new JButton("Open Image...");
        openButton.addActionListener(e -> openImageFromDisk());

        // Send image to SecurityService
        JButton scanButton = new JButton("Scan Picture");
        scanButton.addActionListener(e -> {
            if (currentCameraImage == null) {
                JOptionPane.showMessageDialog(
                        this,
                        "No image loaded. Click \"Refresh Camera\" or \"Open Image...\" first.",
                        "No Image",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }
            securityService.processImage(currentCameraImage);
        });

        add(cameraHeader, "span 3, wrap");
        add(cameraLabel, "span 3, wrap");
        add(refreshButton, "split 3");
        add(openButton);
        add(scanButton);

        // show something immediately
        loadDefaultImage();
    }

    /* ----------------- helpers ----------------- */

    private void loadDefaultImage() {
        try {
            var in = getClass().getResourceAsStream(DEFAULT_SAMPLE_PATH);
            if (in == null) {
                JOptionPane.showMessageDialog(
                        this,
                        "Resource " + DEFAULT_SAMPLE_PATH + " not found. Place sample-cat.jpg in src/main/resources.",
                        "Image Not Found",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }
            setImage(ImageIO.read(in));
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load default image.", "Load Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void openImageFromDisk() {
        JFileChooser chooser = new JFileChooser();
        chooser.setCurrentDirectory(new File("."));
        chooser.setDialogTitle("Select Picture");
        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                BufferedImage img = ImageIO.read(chooser.getSelectedFile());
                if (img == null) throw new IOException("Unsupported image format.");
                setImage(img);
            } catch (IOException | NullPointerException ioe) {
                JOptionPane.showMessageDialog(this, "Invalid image selected.", "Load Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void setImage(BufferedImage img) {
        currentCameraImage = img;
        Image scaled = new ImageIcon(img).getImage()
                .getScaledInstance(IMAGE_WIDTH, IMAGE_HEIGHT, Image.SCALE_SMOOTH);
        cameraLabel.setIcon(new ImageIcon(scaled));
        repaint();
    }

    /* --------------- StatusListener --------------- */

    @Override
    public void notify(AlarmStatus status) {
        // no-op here; header text updates in catDetected()
    }

    @Override
    public void catDetected(boolean catDetected) {
        cameraHeader.setText(catDetected
                ? "DANGER - CAT DETECTED"
                : "Camera Feed - No Cats Detected");
    }

    @Override
    public void sensorStatusChanged() {
        // no behavior necessary
    }
}
