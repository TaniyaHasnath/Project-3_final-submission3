package com.udacity.catpoint.service;

import com.udacity.catpoint.application.StatusListener;
import com.udacity.catpoint.data.AlarmStatus;
import com.udacity.catpoint.data.ArmingStatus;
import com.udacity.catpoint.data.SecurityRepository;
import com.udacity.catpoint.data.Sensor;

import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.Set;

/**
 * Business logic for the security system.
 */
public class SecurityService {

    private final ImageService imageService;           // <-- depend on the interface
    private final SecurityRepository securityRepository;
    private final Set<StatusListener> statusListeners = new HashSet<>();

    public SecurityService(SecurityRepository securityRepository, ImageService imageService) {
        this.securityRepository = securityRepository;
        this.imageService = imageService;
    }

    /** Arming changes may update alarm status. */
    public void setArmingStatus(ArmingStatus armingStatus) {
        if (armingStatus == ArmingStatus.DISARMED) {
            setAlarmStatus(AlarmStatus.NO_ALARM);
        }
        securityRepository.setArmingStatus(armingStatus);
    }

    /** Notify listeners and persist the new alarm status. */
    public void setAlarmStatus(AlarmStatus status) {
        securityRepository.setAlarmStatus(status);
        statusListeners.forEach(l -> l.notify(status));
    }

    /** Register/unregister listeners. */
    public void addStatusListener(StatusListener listener) { statusListeners.add(listener); }
    public void removeStatusListener(StatusListener listener) { statusListeners.remove(listener); }

    /** Handle image and update alarm by cat detection + arming mode. */
    public void processImage(BufferedImage currentCameraImage) {
        boolean cat = imageService.imageContainsCat(currentCameraImage, 50.0f);
        if (cat && getArmingStatus() == ArmingStatus.ARMED_HOME) {
            setAlarmStatus(AlarmStatus.ALARM);
        } else {
            setAlarmStatus(AlarmStatus.NO_ALARM);
        }
        statusListeners.forEach(l -> l.catDetected(cat));
    }

    /** Sensor state machine: activating sensors. */
    private void handleSensorActivated() {
        if (securityRepository.getArmingStatus() == ArmingStatus.DISARMED) return;

        switch (securityRepository.getAlarmStatus()) {
            case NO_ALARM -> setAlarmStatus(AlarmStatus.PENDING_ALARM);
            case PENDING_ALARM -> setAlarmStatus(AlarmStatus.ALARM);
            default -> { /* no-op for ALARM */ }
        }
    }

    /** Sensor state machine: deactivating sensors. */
    private void handleSensorDeactivated() {
        switch (securityRepository.getAlarmStatus()) {
            case PENDING_ALARM -> setAlarmStatus(AlarmStatus.NO_ALARM);
            case ALARM -> setAlarmStatus(AlarmStatus.PENDING_ALARM);
            default -> { /* NO_ALARM -> no-op */ }
        }
    }

    /** Toggle a sensor and update repository + alarm if needed. */
    public void changeSensorActivationStatus(Sensor sensor, Boolean active) {
        if (!sensor.getActive() && active) {
            handleSensorActivated();
        } else if (sensor.getActive() && !active) {
            handleSensorDeactivated();
        }
        sensor.setActive(active);
        securityRepository.updateSensor(sensor);
        statusListeners.forEach(StatusListener::sensorStatusChanged);
    }

    // Passthroughs
    public AlarmStatus getAlarmStatus() { return securityRepository.getAlarmStatus(); }
    public Set<Sensor> getSensors()      { return securityRepository.getSensors(); }
    public void addSensor(Sensor sensor) { securityRepository.addSensor(sensor); }
    public void removeSensor(Sensor s)   { securityRepository.removeSensor(s); }
    public ArmingStatus getArmingStatus(){ return securityRepository.getArmingStatus(); }
}
