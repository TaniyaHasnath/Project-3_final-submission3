package com.udacity.catpoint.application;

import com.udacity.catpoint.data.PretendDatabaseSecurityRepositoryImpl;
import com.udacity.catpoint.data.SecurityRepository;
import com.udacity.catpoint.service.ImageService;       // ← use the interface
import com.udacity.catpoint.service.FakeImageService;  // ← implementation stays fake
import com.udacity.catpoint.service.SecurityService;
import net.miginfocom.swing.MigLayout;

import javax.swing.*;

/**
 * Primary JFrame for the Catpoint application.
 * Constructs dependencies (no DI framework) and wires up the panels.
 */
public class CatpointGui extends JFrame {
    private static final long serialVersionUID = 1L;

    private final SecurityRepository securityRepository = new PretendDatabaseSecurityRepositoryImpl();
    private final ImageService imageService = new FakeImageService();  // ← FAKE, not AWS
    private final SecurityService securityService = new SecurityService(securityRepository, imageService);

    private final DisplayPanel displayPanel = new DisplayPanel(securityService);
    private final ControlPanel controlPanel = new ControlPanel(securityService);
    private final SensorPanel sensorPanel = new SensorPanel(securityService);
    private final ImagePanel imagePanel = new ImagePanel(securityService);

    public CatpointGui() {
        setTitle("Very Secure App");
        setLocation(100, 100);
        setSize(600, 850);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel(new MigLayout());
        mainPanel.add(displayPanel, "wrap");
        mainPanel.add(imagePanel, "wrap");
        mainPanel.add(controlPanel, "wrap");
        mainPanel.add(sensorPanel);

        getContentPane().add(mainPanel);
    }
}
