package com.udacity.catpoint.application;

import javax.swing.SwingUtilities;

public class CatpointApp {
    public static void main(String[] args) {
        new CatpointGui();
        // Launch Swing on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            // If CatpointGui has a no-arg constructor, this works.
            CatpointGui gui = new CatpointGui();
            gui.setVisible(true);
        });
    }
}
