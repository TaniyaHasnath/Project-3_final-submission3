package com.udacity.catpoint.service;

import com.udacity.catpoint.application.StatusListener;
import com.udacity.catpoint.data.AlarmStatus;
import com.udacity.catpoint.data.ArmingStatus;
import com.udacity.catpoint.data.SecurityRepository;
import com.udacity.catpoint.data.Sensor;
import com.udacity.catpoint.data.SensorType;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentCaptor.forClass;
import static org.mockito.Mockito.*;

class SecurityServiceTest {

    private SecurityRepository repo;
    private ImageService image;
    private SecurityService service;

    private final Sensor door = new Sensor("front door", SensorType.DOOR);
    private final Sensor window = new Sensor("kitchen window", SensorType.WINDOW);

    @BeforeEach
    void setUp() {
        repo = mock(SecurityRepository.class);
        image = mock(ImageService.class);
        service = new SecurityService(repo, image);

        // sensible defaults
        when(repo.getArmingStatus()).thenReturn(ArmingStatus.DISARMED);
        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.NO_ALARM);
        when(repo.getSensors()).thenReturn(new HashSet<>(Set.of(door, window)));
    }

    // --- setArmingStatus ---

    @Test
    void disarming_setsAlarmToNoAlarm() {
        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);

        service.setArmingStatus(ArmingStatus.DISARMED);

        verify(repo).setArmingStatus(ArmingStatus.DISARMED);
        verify(repo).setAlarmStatus(AlarmStatus.NO_ALARM);
    }

    @Test
    void arming_doesNotChangeAlarmDirectly() {
        service.setArmingStatus(ArmingStatus.ARMED_AWAY);

        verify(repo).setArmingStatus(ArmingStatus.ARMED_AWAY);
        verify(repo, never()).setAlarmStatus(any());
    }

    // --- changeSensorActivationStatus (activate) ---

    @Test
    void activatingSensor_whenDisarmed_doesNothingToAlarm() {
        when(repo.getArmingStatus()).thenReturn(ArmingStatus.DISARMED);
        door.setActive(false);

        service.changeSensorActivationStatus(door, true);

        verify(repo, never()).setAlarmStatus(any());
        assertTrue(door.getActive());
        verify(repo).updateSensor(door);
    }

    @Test
    void activatingSensor_fromNoAlarm_goesToPending_whenArmed() {
        when(repo.getArmingStatus()).thenReturn(ArmingStatus.ARMED_AWAY);
        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.NO_ALARM);
        door.setActive(false);

        service.changeSensorActivationStatus(door, true);

        verify(repo).setAlarmStatus(AlarmStatus.PENDING_ALARM);
    }

    @Test
    void activatingSensor_fromPending_goesToAlarm_whenArmed() {
        when(repo.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        window.setActive(false);

        service.changeSensorActivationStatus(window, true);

        verify(repo).setAlarmStatus(AlarmStatus.ALARM);
    }

    // --- changeSensorActivationStatus (deactivate) ---

    @Test
    void deactivatingSensor_fromPending_goesToNoAlarm() {
        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        door.setActive(true);

        service.changeSensorActivationStatus(door, false);

        verify(repo).setAlarmStatus(AlarmStatus.NO_ALARM);
    }

    @Test
    void deactivatingSensor_fromAlarm_goesToPending() {
        when(repo.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);
        window.setActive(true);

        service.changeSensorActivationStatus(window, false);

        verify(repo).setAlarmStatus(AlarmStatus.PENDING_ALARM);
    }

    // --- processImage / catDetected ---

    @Test
    void catDetected_whileArmedHome_setsAlarm() {
        when(repo.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        when(image.imageContainsCat(any(BufferedImage.class), anyFloat())).thenReturn(true);

        service.processImage(new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB));

        verify(repo).setAlarmStatus(AlarmStatus.ALARM);
    }

    @Test
    void noCatDetected_setsNoAlarm() {
        when(image.imageContainsCat(any(BufferedImage.class), anyFloat())).thenReturn(false);

        service.processImage(new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB));

        verify(repo).setAlarmStatus(AlarmStatus.NO_ALARM);
    }

    // --- listener notification sanity ---

    @Test
    void setAlarmStatus_notifiesListeners() {
        var listener = mock(StatusListener.class);
        service.addStatusListener(listener);

        service.setAlarmStatus(AlarmStatus.ALARM); // ensure this method is public in SecurityService

        var captor = forClass(AlarmStatus.class);
        verify(listener).notify(captor.capture());
        assertEquals(AlarmStatus.ALARM, captor.getValue());
    }
}
